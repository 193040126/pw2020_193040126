<!DOCTYPE html>
<html>
<head>
	<title>penjumlahan</title>
</head>
<body>
	<form method="get" action="actionjumlah.php">
		<table>

			<tr>
				<td>angka</td>
				<td><input type="text" name="angka1"></td>
			</tr>

			<tr>
				<td>angka</td>
				<td><input type="text" name="angka2"></td>
			</tr>

			<tr>
				<td></td>
				<td><button type="submit">lihat hasil</button></td>
			</tr>

		</table>
	</form>

</body>
</html>