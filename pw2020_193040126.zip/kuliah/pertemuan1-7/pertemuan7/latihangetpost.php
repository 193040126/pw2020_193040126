<!DOCTYPE html>
<html>
<head>
	<title>latihan get & post</title>
</head>
<body>
	<form method="get" action="hasilaction.php">
	 	<table>

	 		<tr>
	 			<td>Username</td>
	 			<td><input type="text" name="username"></td>
	 		</tr>

	 		<tr>
	 			<td>Password</td>
	 			<td><input type="password" name="password"></td>
	 		</tr>

	 		<tr>
	 			<td></td>
	 			<td><button type="submit">login</button></td>
	 		</tr>

	 	</table>
	</form>
</body>
</html>