<?php 

	$variabela = "bakso";
	$variabelb = "borak";
	$variabelc = "enak";

	echo $variabela. " itu "  .$variabelb. ", " .$variabelb. " itu " .$variabelc;
 ?>