<?php 
	
	$angka = 15;
	
	echo "aku adalah angka ". $angka. "<br>" ;
	echo "jika aku dikali 5 maka, aku sekarang bernilai " . ($angka *= 5). "<br>";
	echo "jika aku dibagi 3 maka, aku sekarang bernilai " . ($angka /= 3). "<br>";
	echo "jika aku dikurang 30 maka, aku sekarang bernilai " . ($angka -= 30). "<br>";
	echo "jika aku ditambah 10 maka, aku sekarang bernilai " . ($angka += 10). "<br>";



 ?>