<?php 
	//pembuatan variabel
	//rumus
	$nama_variabel = "VALUE";



	//data pribadi
	// $nama = "samsul";  //string
	// $umur = 25;

	// echo $nama;
	// echo "<br>";
	// echo $umur. " tahun";
	// echo "<br>";
	// echo "25 ". " 25";


	$x = 5;
	$y = 3;

	$x += 3;

	echo $x%$y;
 ?>	