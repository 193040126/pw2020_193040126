<?php 
	//for
	// $i = 1;
	// for ($i=0; $i <9 ; $i+=2) { 
	// 	echo "nilai " .$i. "<br>";
	// }

	//while
	// $i = 1;
	// while ($i <= 10) {
	// 	echo "nilai " .$i. "<br>";
	// 	$i++;
	// }

	//do while
	$i = 0;
	do {
		echo "nilai " .$i. "<br>";
		$i++;
	} while ($i <= 10) ;
		
	
	echo "nilai akhir i = " .$i ;

	
 ?>