<?php 

	/*
	$nilai = 54;
	if ($nilai>= 55) {
		echo "lulus";
	} else{
		echo "tidak lulus";
	}
	*/


	//konstanta
	// define("test", "testing konstanta");

	// echo test;

	//ternary
	// $nilai = 9999999;
	// $hasil = ($nilai%2 == 0)? "genap":"ganjil";

	// echo $hasil;


	//if (($nilai 1%2) == 1){
	//	echo "ganjil";
	//} else{
	//	echo "genap";
	//}



// pengkondisian if else if
// 	$warna_lampu = "hijau";

// 	if ($warna_lampu == "merah"){
// 		echo "Stop";
// 	} elseif ($warna_lampu == "kuning") {
// 		echo "Ready bos";
// 	} elseif ($warna_lampu == "hijau"){
// 		echo "gas slurr";
// 	} else {
// 		echo "warna tidak dikenal";
// 	} 


	// $hari = 1;
	// if ($hari <= 1) {
	// 	echo "hari ahad dari if";
	// } elseif ($hari == 1) {
	// 	echo "hari isnen dari if";
	// }
	// echo "<br>";



	// $hari = 1;
	// switch ($hari) {
	// 	case 1:
	// 		echo "hari ahad dari switch";
	// 		break;


	// 	case 2:
	// 		echo "hari isnen dari switch";
	// 		break;

	// 	default:
	// 		echo "hari not knowing";
	// 		break;
	// }
	






	

 ?>